import pygame
import sys
import time
import random
from pygame import mixer

# Inicializar pygame
pygame.init()
mixer.init()

# Configuración de la ventana
width, height = 800, 600
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Carta Romántica")

# Colores
WHITE = (255, 255, 255)
RED = (255, 0, 0)
PINK = (255, 192, 203)
BLACK = (0, 0, 0)

# Cargar música (reemplaza con la ruta de tu archivo de música)
try:
    mixer.music.load("romantic_music.mp3")  # Cambia por tu archivo de música
    mixer.music.set_volume(0.5)
    mixer.music.play(-1)  # -1 para reproducir en bucle
except:
    print("No se pudo cargar la música. Continuando sin música...")

# Fuentes
title_font = pygame.font.SysFont('comicsansms', 40)
text_font = pygame.font.SysFont('arial', 20)

# Función para dibujar un corazón
def draw_heart(surface, x, y, size):
    pygame.draw.circle(surface, RED, (x, y), size)
    pygame.draw.circle(surface, RED, (x + size, y), size)
    pygame.draw.polygon(surface, RED, [
        (x - size, y),
        (x + size * 2, y),
        (x + size / 2, y + size * 2)
    ])

# Función para dibujar corazones en los bordes
def draw_hearts_border():
    heart_size = 10
    spacing = 30
    
    # Borde superior
    for x in range(0, width, spacing):
        draw_heart(screen, x, 20, heart_size)
    
    # Borde inferior
    for x in range(0, width, spacing):
        draw_heart(screen, x, height - 20, heart_size)
    
    # Borde izquierdo
    for y in range(0, height, spacing):
        draw_heart(screen, 20, y, heart_size)
    
    # Borde derecho
    for y in range(0, height, spacing):
        draw_heart(screen, width - 20, y, heart_size)

# Texto de la carta
def draw_letter():
    # Fondo
    screen.fill(WHITE)
    
    # Dibujar corazones en los bordes
    draw_hearts_border()
    
    # Título
    title = title_font.render("Para Mi Amor", True, PINK)
    screen.blit(title, (width//2 - title.get_width()//2, 50))
    
    # Contenido de la carta
    lines = [
        "Querida mía,",
        "",
        "En este día especial, quiero decirte que",
        "eres lo más importante en mi vida. Cada",
        "momento a tu lado es un regalo que atesoro",
        "en lo más profundo de mi corazón.",
        "",
        "Tu sonrisa ilumina mis días y tu amor",
        "da sentido a mi existencia. Espero que",
        "esta pequeña carta te haga sonreír tanto",
        "como tú me haces sonreír a mí cada día.",
        "",
        "Con todo mi amor,",
        "Para siempre, tu amor."
    ]
    
    y_offset = 120
    for line in lines:
        text = text_font.render(line, True, BLACK)
        screen.blit(text, (width//2 - text.get_width()//2, y_offset))
        y_offset += 30

# Bucle principal
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
    
    # Dibujar la carta
    draw_letter()
    
    # Actualizar pantalla
    pygame.display.flip()
    pygame.time.delay(30)

# Salir
pygame.quit()
sys.exit()